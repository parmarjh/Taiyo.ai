API_KEY = "..."

#API key=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